#include <iostream>
#include <fstream>
#include <nlohmann/json.hpp>
using json = nlohmann::json;
int main() {
    std::ifstream file("../bxgm/game.json");
    if (!file) { std::cerr << "Game file not found!\n"; return 1; }
    json game; file >> game;
    std::cout << "Loaded game objects: " << game.dump(2) << std::endl;
    std::cout << "Engine running...\n";
}