import json
def load_game(file_path='../bxgm/game.json'):
    with open(file_path) as f:
        data = json.load(f)
    return data
def run_lua_script(script):
    print("Lua script would run here:", script)
if __name__ == '__main__':
    game = load_game()
    print("Loaded game:", game)
