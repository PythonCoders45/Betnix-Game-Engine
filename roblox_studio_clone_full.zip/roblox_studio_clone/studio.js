// Minimal Studio JS with Lua integration
const canvas = document.getElementById('canvas');
const renderer = new THREE.WebGLRenderer({canvas});
renderer.setSize(window.innerWidth-550, window.innerHeight-40);
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(60,(window.innerWidth-550)/(window.innerHeight-40),0.1,1000);
camera.position.set(5,5,5); camera.lookAt(0,0,0);
scene.add(new THREE.AmbientLight(0xffffff,0.8));
scene.add(new THREE.GridHelper(20,20));
let objects=[]; let selectedObject=null;
const builtInFolders=[{name:"Workspace",children:[]},{name:"Scripts",children:[]},{name:"Models",children:[]},{name:"Assets",children:[]}];
const outputLog=document.getElementById('outputLog');
const propertiesPanel=document.getElementById('properties');
function logOutput(msg){outputLog.textContent+=msg+'\n';}
function addCube(){const g=new THREE.BoxGeometry(1,1,1);const m=new THREE.MeshStandardMaterial({color:0x3399ff});const mesh=new THREE.Mesh(g,m);mesh.position.set(Math.random()*5,0.5,Math.random()*5);scene.add(mesh);const obj={mesh,type:'cube',luaCode:'print("Hello Cube!")'};objects.push(obj);builtInFolders[0].children.push({name:"Cube",object:obj});updateGameFiles();}
function updateGameFiles(){const gf=document.getElementById('gameFiles');gf.innerHTML='';builtInFolders.forEach(folder=>{const div=document.createElement('div');div.textContent=folder.name;div.style.fontWeight='bold';gf.appendChild(div);folder.children.forEach(child=>{const childDiv=document.createElement('div');childDiv.textContent='  '+child.name;childDiv.onclick=()=>{selectedObject=child.object;updateProperties();};gf.appendChild(childDiv);});});}
function updateProperties(){if(!selectedObject){propertiesPanel.innerHTML="Select an object";return;}const p=selectedObject.mesh.position;const r=selectedObject.mesh.rotation;const s=selectedObject.mesh.scale;propertiesPanel.innerHTML=`<b>Type:</b>${selectedObject.type}<br><b>Position:</b>${p.x.toFixed(2)},${p.y.toFixed(2)},${p.z.toFixed(2)}<br><b>Rotation:</b>${r.x.toFixed(2)},${r.y.toFixed(2)},${r.z.toFixed(2)}<br><b>Scale:</b>${s.x.toFixed(2)},${s.y.toFixed(2)},${s.z.toFixed(2)}<br><b>Scripts:</b>${selectedObject.luaCode?"Lua attached":"None"}`;}
function runLua(code){try{const L=fengari.lauxlib.luaL_newstate();fengari.lualib.luaL_openlibs(L);fengari.lua.lua_register(L,"print",function(L){const msg=fengari.to_jsstring(fengari.lua.lua_tostring(L,1));logOutput(msg);return 0;});fengari.lauxlib.luaL_dostring(L,code);logOutput("Lua executed successfully.");}catch(e){logOutput("Lua Error: "+e);}}
function runSelectedScript(){if(!selectedObject||!selectedObject.luaCode)return;runLua(selectedObject.luaCode);}
function saveGame(){const zip=new JSZip();const gameData={folders:builtInFolders};zip.file("game.json",JSON.stringify(gameData,null,2));zip.generateAsync({type:"blob"}).then(blob=>{const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download="game.bxgm";a.click();});}
document.getElementById('loadGameInput').addEventListener('change',function(e){const file=e.target.files[0];if(!file)return;JSZip.loadAsync(file).then(zip=>{zip.file("game.json").async("string").then(txt=>{const data=JSON.parse(txt);console.log("Loaded:",data);});});});
function showTab(tab){document.querySelectorAll('.tabContent').forEach(t=>t.style.display='none');document.getElementById(tab+'Tab').style.display='block';}
canvas.addEventListener('click',e=>{const mouse=new THREE.Vector2((e.clientX/(window.innerWidth-550))*2-1,-(e.clientY/(window.innerHeight-40))*2+1);const raycaster=new THREE.Raycaster();raycaster.setFromCamera(mouse,camera);const intersects=raycaster.intersectObjects(objects.map(o=>o.mesh));if(intersects.length>0)selectedObject=objects.find(o=>o.mesh===intersects[0].object);else selectedObject=null;updateProperties();});
function animate(){requestAnimationFrame(animate);renderer.render(scene,camera);}
animate();window.addCube=addCube;window.logOutput=logOutput;
function runPythonBackend(){logOutput("Python backend trigger placeholder");}
function buildAndRunCpp(){logOutput("C++ build/run placeholder");}
